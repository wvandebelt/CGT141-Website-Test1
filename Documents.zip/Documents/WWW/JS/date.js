
var dataStored = {time:"",place:"",wait:""};

function storedDiningData(court,time) {
	
	var date = new Date();
	dataStored.time = date;
	dataStored.place = court;
	dataStored.wait = time;
	
	//console.log(dataStored);
}

function storedBarData(bar,time) {
	
	var date = new Date();
	dataStored.time = date;
	dataStored.place = bar;
	dataStored.wait = time;
	
	//console.log(dataStored);
}

function earhartTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//earhart on Sunday
	if (currentDay == 0) {
		//earhart closed till lunch
		if(currentHour < 10) {
			document.getElementById("buttonFillerClosed").style.display = "block";
			document.getElementById("buttonFillerClosed").innerHTML = "Earhart is Closed";
		}
		//earhart lunch
		else if (currentHour >=10 && currentHour <14) {
			document.getElementById("buttonFillerOpen").style.display = "block";
			document.getElementById("buttonFillerOpen").innerHTML = "15-30 min";
		}
		//earhart closed for the day
		else if (currentHour >= 14) {
			document.getElementById("buttonFillerClosed").style.display = "block";
			document.getElementById("buttonFillerClosed").innerHTML = "Earhart is Closed";
		}
	}
	
	//earhart on monday -> Friday
	else if (currentDay == 1 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5) {
		//closed till breakfast
		if (currentHour < 7) {
			document.getElementById("buttonFillerClosed").style.display = "block";
			document.getElementById("buttonFillerClosed").innerHTML = "Earhart is Closed";
		}
		//earhart breakfast
		if (currentHour >= 7 && currentHour < 10) {
			document.getElementById("buttonFillerOpen").style.display = "block";
			document.getElementById("buttonFillerOpen").innerHTML = "0-15 min";
		}
		//closed before lunch
		else if (currentHour >= 10 && currentHour < 11) {
			document.getElementById("buttonFillerClosed").style.display = "block";
			document.getElementById("buttonFillerClosed").innerHTML = "Earhart is Closed";
		}
		//earhart lunch
		else if (currentHour >= 11 && currentHour < 14) {
			document.getElementById("buttonFillerOpen").style.display = "block";
			document.getElementById("buttonFillerOpen").innerHTML = "10-20 min";
		}
		//closed before dinner
		else if (currentHour >= 14 && currentHour < 17) {
			document.getElementById("buttonFillerClosed").style.display = "block";
			document.getElementById("buttonFillerClosed").innerHTML = "Earhart is Closed";
		}
		//earhart dinner
		else if (currentHour >= 17 && currentHour < 21) {
			document.getElementById("buttonFillerOpen").style.display = "block";
			document.getElementById("buttonFillerOpen").innerHTML = "15-30 min";
		}
		//closed after dinner
		else if (currentHour >= 21) {
			document.getElementById("buttonFillerClosed").style.display = "block";
			document.getElementById("buttonFillerClosed").innerHTML = "Earhart is Closed";
		}
	}
	
	//earhart on saturday
	else if (currentDay == 6) {
		//closed till breakfast
		if (currentHour < 10) {
			document.getElementById("buttonFillerClosed").style.display = "block";
			document.getElementById("buttonFillerClosed").innerHTML = "Earhart is Closed";
		}
		//earhart lunch
		else if (currentHour >= 10 && currentHour < 14) {
			document.getElementById("buttonFillerOpen").style.display = "block";
			document.getElementById("buttonFillerOpen").innerHTML = "15-30 min";
		}
		//earhart closed till dinner
		else if (currentHour >= 14 && currentHour < 17) {
			document.getElementById("buttonFillerClosed").style.display = "block";
			document.getElementById("buttonFillerClosed").innerHTML = "Earhart is Closed";
		}
		//earhart dinner
		else if (currentHour >= 17 && currentHour < 20) {
			document.getElementById("buttonFillerOpen").style.display = "block";
			document.getElementById("buttonFillerOpen").innerHTML = "15-30 min";
		}
	}
	
}

function fordTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//Ford Sunday
	if (currentDay == 0) {
		//closed till lunch
		if (currentHour < 11) {
			document.getElementById("buttonFillerClosed1").style.display = "block";
			document.getElementById("buttonFillerClosed1").innerHTML = "Ford is Closed";
		}
		//ford lunch
		else if (currentHour >= 11 && currentHour < 14) {
			document.getElementById("buttonFillerOpen1").style.display = "block";
			document.getElementById("buttonFillerOpen1").innerHTML = "20-40 min";
		}
		//ford closed for day
		else if (currentHour >= 14) {
			document.getElementById("buttonFillerClosed1").style.display = "block";
			document.getElementById("buttonFillerClosed1").innerHTML = "Ford is Closed";
		}
	}
	
	//ford on monday -> Friday
	else if (currentDay == 1 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5) {
		//closed till breakfast
		if (currentHour >= 0 && currentHour < 7) {
			document.getElementById("buttonFillerClosed1").style.display = "block";
			document.getElementById("buttonFillerClosed1").innerHTML = "Ford is Closed";
		}
		//ford breakfast
		else if (currentHour >= 7 && currentHour < 11) {
			document.getElementById("buttonFillerOpen1").style.display = "block";
			document.getElementById("buttonFillerOpen1").innerHTML = "0-10 min";
		}
		//ford lunch
		else if (currentHour >= 11 && currentHour < 14) {
			document.getElementById("buttonFillerOpen1").style.display = "block";
			document.getElementById("buttonFillerOpen1").innerHTML = "15-30 min";
		}
		//ford late lunch
		else if (currentHour >= 14 && currentHour < 17) {
			document.getElementById("buttonFillerOpen1").style.display = "block";
			document.getElementById("buttonFillerOpen1").innerHTML = "20-40 min";
		}
		//ford dinner
		else if (currentHour >= 17 && currentHour < 20) {
			document.getElementById("buttonFillerOpen1").style.display = "block";
			document.getElementById("buttonFillerOpen1").innerHTML = "20-40 min";
		}
		//ford closed
		else if (currentHour >= 20) {
			document.getElementById("buttonFillerClosed1").style.display = "block";
			document.getElementById("buttonFillerClosed1").innerHTML = "Ford is Closed";
		}
	}
	
	//ford Saturday
	else if (currentDay == 6) {
		//closed till lunch
		if (currentHour < 11) {
			document.getElementById("buttonFillerClosed1").style.display = "block";
			document.getElementById("buttonFillerClosed1").innerHTML = "Ford is Closed";
		}
		//ford lunch
		else if (currentHour >= 11 && currentHour < 14) {
			document.getElementById("buttonFillerOpen1").style.display = "block";
			document.getElementById("buttonFillerOpen1").innerHTML = "20-40 min";
		}
		//closed till dinner
		else if (currentHour >= 14 && currentHour < 17) {
			document.getElementById("buttonFillerClosed1").style.display = "block";
			document.getElementById("buttonFillerClosed1").innerHTML = "Ford is Closed";
		}
		//ford dinner
		else if (currentHour >= 17 && currentHour < 20) {
			document.getElementById("buttonFillerOpen1").style.display = "block";
			document.getElementById("buttonFillerOpen1").innerHTML = "20-40 min";
		}
		//ford closed for day
		else if (currentHour >= 20) {
			document.getElementById("buttonFillerClosed1").style.display = "block";
			document.getElementById("buttonFillerClosed1").innerHTML = "Ford is Closed";
		}
	}
}

function hillenbrandTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	//hillenbrand Sunday
	if (currentDay == 0) {
		//closed till lunch
		if (currentHour < 10) {
			document.getElementById("buttonFillerClosed2").style.display = "block";
			document.getElementById("buttonFillerClosed2").innerHTML = "Hillenbrand is Closed";
		}
		//hillenbrand lunch
		else if (currentHour >=10 && currentHour <14) {
			document.getElementById("buttonFillerOpen2").style.display = "block";
			document.getElementById("buttonFillerOpen2").innerHTML = "10-20 min";
		}
		//closed for the day
		else if (currentHour >=14) {
			document.getElementById("buttonFillerClosed2").style.display = "block";
			document.getElementById("buttonFillerClosed2").innerHTML = "Hillenbrand is Closed";
		}
	}
	//hillenbrand mon -> fri
	else if (currentDay == 1 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5) {
		//closed till lunch
		if (currentHour < 10) {
			document.getElementById("buttonFillerClosed2").style.display = "block";
			document.getElementById("buttonFillerClosed2").innerHTML = "Hillenbrand is Closed";
		}
		//hillenbrand lunch
		else if (currentHour >=10 && currentHour < 14) {
			document.getElementById("buttonFillerOpen2").style.display = "block";
			document.getElementById("buttonFillerOpen2").innerHTML = "10-20 min";
		}
		//hillenbrand late lunch
		else if (currentHour >=14 && currentHour < 17) {
			document.getElementById("buttonFillerOpen2").style.display = "block";
			document.getElementById("buttonFillerOpen2").innerHTML = "10-20 min";
		}
		//hillenbrand dinner
		else if (currentHour >=17 && currentHour < 20) {
			document.getElementById("buttonFillerOpen2").style.display = "block";
			document.getElementById("buttonFillerOpen2").innerHTML = "10-20 min";
		}
		//closed for the day
		else if (currentHour >= 20) {
			document.getElementById("buttonFillerClosed2").style.display = "block";
			document.getElementById("buttonFillerClosed2").innerHTML = "Hillenbrand is Closed";
		}
	}
	//hillenbrand saturday
	else if (currentDay == 6) {
		//closed till lunch
		if (currentHour < 10) {
			document.getElementById("buttonFillerClosed2").style.display = "block";
			document.getElementById("buttonFillerClosed2").innerHTML = "Hillenbrand is Closed";
		}
		//hillenbrand lunch
		else if (currentHour >=10 && currentHour < 14) {
			document.getElementById("buttonFillerOpen2").style.display = "block";
			document.getElementById("buttonFillerOpen2").innerHTML = "10-20 min";
		}
		//closed for the day
		else if (currentHour >=14) {
			document.getElementById("buttonFillerClosed2").style.display = "block";
			document.getElementById("buttonFillerClosed2").innerHTML = "Hillenbrand is Closed";
		}
	}
}

function wileyTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//wiley sunday
	if (currentDay == 0) {
		//closed till breakfast
		if (currentHour < 8) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
		//breakfast
		else if (currentHour >=8 && currentHour < 10) {
			document.getElementById("buttonFillerOpen3").style.display = "block";
			document.getElementById("buttonFillerOpen3").innerHTML = "0-10 min";
		}
		//closed till lunch
		else if (currentHour >=10 && currentHour <11) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
		//wiley lunch
		else if (currentHour >=11 && currentHour <14) {
			document.getElementById("buttonFillerOpen3").style.display = "block";
			document.getElementById("buttonFillerOpen3").innerHTML = "20-40 min";
		}
		//closed for the day
		else if (currentHour >=14) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed Sun";
		}
	}
	
	//wiley mon->fri
	else if (currentDay == 1 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5) {
		//closed till breakfast
		if (currentHour <6) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
		//breakfast
		else if (currentHour >=6 && currentHour <10) {
			document.getElementById("buttonFillerOpen3").style.display = "block";
			document.getElementById("buttonFillerOpen3").innerHTML = "0-10 min";
		}
		//closed till lunch
		else if (currentHour >=10 && currentHour <11) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
		//wiley lunch
		else if (currentHour >=11 && currentHour <14) {
			document.getElementById("buttonFillerOpen3").style.display = "block";
			document.getElementById("buttonFillerOpen3").innerHTML = "20-40 min";
		}
		//closed till dinner
		else if (currentHour >=14 && currentHour <17) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
		//wiley dinner
		else if (currentHour >=17 && currentHour <21) {
			document.getElementById("buttonFillerOpen3").style.display = "block";
			document.getElementById("buttonFillerOpen3").innerHTML = "20-40 min";
		}
		//closed for the day
		else if (currentHour >=21) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
	}
	
	//wiley saturday
	else if (currentDay == 6) {
		//closed till breakfast
		if (currentHour < 8) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
		//breakfast
		else if (currentHour >=8 && currentHour < 10) {
			document.getElementById("buttonFillerOpen3").style.display = "block";
			document.getElementById("buttonFillerOpen3").innerHTML = "0-10 min";
		}
		//closed till lunch
		else if (currentHour >=10 && currentHour <11) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
		//lunch
		else if (currentHour >=11 && currentHour <14) {
			document.getElementById("buttonFillerOpen3").style.display = "block";
			document.getElementById("buttonFillerOpen3").innerHTML = "15-30 min";
		}
		//closed till dinner
		else if (currentHour >=14 && currentHour <17) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
		//dinner
		else if (currentHour >=17 && currentHour <20) {
			document.getElementById("buttonFillerOpen3").style.display = "block";
			document.getElementById("buttonFillerOpen3").innerHTML = "20-40 min";
		}
		//closed for the day
		else if (currentHour >=20) {
			document.getElementById("buttonFillerClosed3").style.display = "block";
			document.getElementById("buttonFillerClosed3").innerHTML = "Wiley is closed";
		}
	}
}

function windsorTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//windsor Sunday
	if (currentDay == 0) {
		document.getElementById("buttonFillerClosed4").style.display = "block";
		document.getElementById("buttonFillerClosed4").innerHTML = "Windsor is closed";
	}
	//windsor Mon->fri
	else if (currentDay == 1 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5) {
		//closed till lunch
		if (currentHour < 10) {
			document.getElementById("buttonFillerClosed4").style.display = "block";
			document.getElementById("buttonFillerClosed4").innerHTML = "Windsor is closed";
		}
		//lunch
		else if (currentHour >=10 && currentHour <14) {
			document.getElementById("buttonFillerOpen4").style.display = "block";
			document.getElementById("buttonFillerOpen4").innerHTML = "10-20 min";
		}
		//late lunch
		else if (currentHour >=14 && currentHour <17) {
			document.getElementById("buttonFillerOpen4").style.display = "block";
			document.getElementById("buttonFillerOpen4").innerHTML = "15-30 min";
		}
		//dinner
		else if (currentHour >=17 && currentHour <22) {
			document.getElementById("buttonFillerOpen4").style.display = "block";
			document.getElementById("buttonFillerOpen4").innerHTML = "15-30 min";
		}
		//closed for the day
		else if (currentHour >=22) {
			document.getElementById("buttonFillerClosed4").style.display = "block";
			document.getElementById("buttonFillerClosed4").innerHTML = "Windsor is closed";
		}
	}
	
	//windsor saturday
	else if (currentDay == 6) {
		//closed till dinner
		if (currentHour <16) {
			document.getElementById("buttonFillerClosed4").style.display = "block";
			document.getElementById("buttonFillerClosed4").innerHTML = "Windsor is closed";
		}
		//dinner
		else if (currentHour >=16 && currentHour <20) {
			document.getElementById("buttonFillerOpen4").style.display = "block";
			document.getElementById("buttonFillerOpen4").innerHTML = "15-30 min";
		}
		//closed for the day
		else if (currentHour >=20) {
			document.getElementById("buttonFillerClosed4").style.display = "block";
			document.getElementById("buttonFillerClosed4").innerHTML = "Windsor is closed";
		}
	}
}

function gatheringPlaceTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//gatheringPlace Sunday, friday, saturday
	if (currentDay == 0 || currentDay == 5 || currentDay == 6) {
		document.getElementById("buttonFillerClosed5").style.display = "block";
		document.getElementById("buttonFillerClosed5").innerHTML = "Gathering Place closed";
	}
	
	//gathering Place mon-thurs
	else if (currentDay == 1 || currentDay == 2 || currentDay == 3 || currentDay == 4) {
		//closed till dinner
		if (currentHour < 17) {
			document.getElementById("buttonFillerClosed5").style.display = "block";
			document.getElementById("buttonFillerClosed5").innerHTML = "Gathering Place closed";
		}
		//dinner
		else if (currentHour >=17 && currentHour <19) {
			document.getElementById("buttonFillerOpen5").style.display = "block";
			document.getElementById("buttonFillerOpen5").innerHTML = "0-10 min";
		}
		//closed for day
		else if (currentHour >=19) {
			document.getElementById("buttonFillerClosed5").style.display = "block";
			document.getElementById("buttonFillerClosed5").innerHTML = "Gathering Place closed";
		}
	}
}

function bar308Time() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//308 tuesday -> Sunday
	if (currentDay == 0 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5 || currentDay == 6) {
		//open till 3 am from yesterday
		if (currentHour < 3) {
			document.getElementById("buttonFillerOpen6").style.display = "block";
			document.getElementById("buttonFillerOpen6").innerHTML = "0-10 min";
		}
		//closed after 3am till 11 same day
		else if (currentHour >=3 && currentHour <11) {
			document.getElementById("buttonFillerClosed6").style.display = "block";
			document.getElementById("buttonFillerClosed6").innerHTML = "308 closed";
		}
		//open from 11 - midnight
		else if (currentHour >=11) {
			document.getElementById("buttonFillerOpen6").style.display = "block";
			document.getElementById("buttonFillerOpen6").innerHTML = "0-10 min";
		}
	}
	
	//monday
	else if (currentDay == 1) {
		//closed till 11
		if (currentHour < 11) {
			document.getElementById("buttonFillerClosed6").style.display = "block";
			document.getElementById("buttonFillerClosed6").innerHTML = "308 closed";
		}
		//open 11 -12am
		else if (currentHour >=11) {
			document.getElementById("buttonFillerOpen6").style.display = "block";
			document.getElementById("buttonFillerOpen6").innerHTML = "0-10 min";
		}
	}
}

function barBrothersTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//brothers mon -> Sat
	if (currentDay == 1 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5 || currentDay == 6) {
		//open till 3 am from yesterday
		if (currentHour < 3) {
			document.getElementById("buttonFillerOpen7").style.display = "block";
			document.getElementById("buttonFillerOpen7").innerHTML = "10-20 min";
		}
		//closed after 3am till 4 same day
		else if (currentHour >=3 && currentHour <16) {
			document.getElementById("buttonFillerClosed7").style.display = "block";
			document.getElementById("buttonFillerClosed7").innerHTML = "Brothers closed";
		}
		//open from 4 - midnight
		else if (currentHour >=16) {
			document.getElementById("buttonFillerOpen7").style.display = "block";
			document.getElementById("buttonFillerOpen7").innerHTML = "20-40 min";
		}
	}
	
	//sunday
	else if (currentDay ==0) {
		//open till 3am from sat
		if (currentHour < 3) {
			document.getElementById("buttonFillerOpen7").style.display = "block";
			document.getElementById("buttonFillerOpen7").innerHTML = "10-20 min";
		}
		//closed till 7pm
		else if (currentHour >=3 && currentHour <19) {
			document.getElementById("buttonFillerClosed7").style.display = "block";
			document.getElementById("buttonFillerClosed7").innerHTML = "Brothers closed";
		}
		//open for rest of day
		else if (currentHour >=19) {
			document.getElementById("buttonFillerOpen7").style.display = "block";
			document.getElementById("buttonFillerOpen7").innerHTML = "10-20 min";
		}
	}
}

function cactusTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//cactus thursday
	if (currentDay == 4) {
		//closed till 8pm
		if (currentHour < 20) {
			document.getElementById("buttonFillerClosed8").style.display = "block";
			document.getElementById("buttonFillerClosed8").innerHTML = "Cactus closed";
		}
		//open for rest of day
		else if (currentHour >=20) {
			document.getElementById("buttonFillerOpen8").style.display = "block";
			document.getElementById("buttonFillerOpen8").innerHTML = "20-40 min";
		}
	}
	
	//cactus fri & Saturday
	else if (currentDay == 5 || currentDay == 6) {
		//open till 3 am
		if (currentHour < 3) {
			document.getElementById("buttonFillerOpen8").style.display = "block";
			document.getElementById("buttonFillerOpen8").innerHTML = "10-20 min";
		}
		//closed till 8pm
		else if (currentHour >=3 && currentHour <20) {
			document.getElementById("buttonFillerClosed8").style.display = "block";
			document.getElementById("buttonFillerClosed8").innerHTML = "Cactus closed";
		}
		//open after 8pm
		else if (currentHour >=20) {
			document.getElementById("buttonFillerOpen8").style.display = "block";
			document.getElementById("buttonFillerOpen8").innerHTML = "15-30 min";
		}
	}
	
	//cactus sunday
	else if (currentDay == 0) {
		//open till 3
		if (currentHour < 3) {
			document.getElementById("buttonFillerOpen8").style.display = "block";
			document.getElementById("buttonFillerOpen8").innerHTML = "0-10 min";
		}
		//closed for rest of day
		else if (currentHour >=3) {
			document.getElementById("buttonFillerClosed8").style.display = "block";
			document.getElementById("buttonFillerClosed8").innerHTML = "Cactus closed";
		}
	}
	
	//cactus mon,tues, wed
	else if (currentDay == 1 || currentDay == 2 ||  currentDay == 3) {
		document.getElementById("buttonFillerClosed8").style.display = "block";
		document.getElementById("buttonFillerClosed8").innerHTML = "Cactus closed";
	}
}

function harrysTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//harrys tuesday -> Sunday
	if (currentDay == 0 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5 || currentDay == 6) {
		//open till 3 am from yesterday
		if (currentHour < 3) {
			document.getElementById("buttonFillerOpen9").style.display = "block";
			document.getElementById("buttonFillerOpen9").innerHTML = "10-20 min";
		}
		//closed after 3am till 11 same day
		else if (currentHour >=3 && currentHour <11) {
			document.getElementById("buttonFillerClosed9").style.display = "block";
			document.getElementById("buttonFillerClosed9").innerHTML = "Harry's closed";
		}
		//open from 11 - midnight
		else if (currentHour >=11) {
			document.getElementById("buttonFillerOpen9").style.display = "block";
			document.getElementById("buttonFillerOpen9").innerHTML = "20-40 min";
		}
	}
	
	//monday
	else if (currentDay == 1) {
		//closed till 11
		if (currentHour < 11) {
			document.getElementById("buttonFillerClosed9").style.display = "block";
			document.getElementById("buttonFillerClosed9").innerHTML = "Harry's closed";
		}
		//open 11 -12am
		else if (currentHour >=11) {
			document.getElementById("buttonFillerOpen9").style.display = "block";
			document.getElementById("buttonFillerOpen9").innerHTML = "10-20 min";
		}
	}
}

function jakesTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//mon - sat
	if (currentDay == 1 || currentDay == 2 || currentDay == 3 || currentDay == 4 || currentDay == 5 || currentDay == 6) {
		//open till 3 am from yesterday
		if (currentHour < 3) {
			document.getElementById("buttonFillerOpen10").style.display = "block";
			document.getElementById("buttonFillerOpen10").innerHTML = "0-10 min";
		}
		//closed after 3am till 11 same day
		else if (currentHour >=3 && currentHour <11) {
			document.getElementById("buttonFillerClosed10").style.display = "block";
			document.getElementById("buttonFillerClosed10").innerHTML = "Jake's closed";
		}
		//open from 11 - midnight
		else if (currentHour >=11) {
			document.getElementById("buttonFillerOpen10").style.display = "block";
			document.getElementById("buttonFillerOpen10").innerHTML = "0-10 min";
		}
	}
	
	//sunday
	else if (currentDay == 0) {
		//open till 3 am from yesterday
		if (currentHour < 3) {
			document.getElementById("buttonFillerOpen10").style.display = "block";
			document.getElementById("buttonFillerOpen10").innerHTML = "0-10 min";
		}
		//closed after 3am till 12 same day
		else if (currentHour >=3 && currentHour <12) {
			document.getElementById("buttonFillerClosed10").style.display = "block";
			document.getElementById("buttonFillerClosed10").innerHTML = "Jake's closed";
		}
		//open from 11 - midnight
		else if (currentHour >=12) {
			document.getElementById("buttonFillerOpen10").style.display = "block";
			document.getElementById("buttonFillerOpen10").innerHTML = "0-10 min";
		}
	}
}

function whereElseTime() {
	
	var currentHour = new Date().getHours();
	var currentDay = new Date().getDay();
	
	//everyday
	if (currentHour < 3) {
		document.getElementById("buttonFillerOpen11").style.display = "block";
		document.getElementById("buttonFillerOpen11").innerHTML = "15-30 min";
	}
	else if (currentHour >=3 && currentHour < 19) {
		document.getElementById("buttonFillerClosed11").style.display = "block";
		document.getElementById("buttonFillerClosed11").innerHTML = "Where Else closed";
	}
	else if (currentHour >= 19) {
		document.getElementById("buttonFillerOpen11").style.display = "block";
		document.getElementById("buttonFillerOpen11").innerHTML = "10-20 min";
	}
}
    
function checkSelected() {
	
	var e = document.getElementById("choice1");
	var strUser = e.options[e.selectedIndex].value;
	
	if (strUser == "diningcourts") {
		document.getElementById("waitTime").style.display = "none";
		document.getElementById("buttonSubmit").style.display = "none";
		document.getElementById("bars").style.display = "none";
		document.getElementById("diningcourts").style.display = "block";
	}
	else if (strUser == "bars") {
		document.getElementById("waitTime").style.display = "none";
		document.getElementById("buttonSubmit").style.display = "none";
		document.getElementById("diningcourts").style.display = "none";
		document.getElementById("bars").style.display = "block";
	}
	else if (strUser == 1) {
		document.getElementById("diningcourts").style.display = "none";
		document.getElementById("bars").style.display = "none";
		document.getElementById("waitTime").style.display = "none";
		document.getElementById("buttonSubmit").style.display = "none";
	}
}

function checkSelected2() {
	document.getElementById("waitTime").style.display = "block";
}

function checkSelected3() {
	
	document.getElementById("buttonSubmit").style.display = "block";
}

function buttonClicked() {
	
	document.getElementById("choice1").style.display = "none";
	document.getElementById("diningcourts").style.display = "none";
	document.getElementById("bars").style.display = "none";
	document.getElementById("waitTime").style.display = "none";
	document.getElementById("buttonSubmit").style.display = "none";
	document.getElementById("buttonFillerOpen12").style.display = "block";
	document.getElementById("buttonFillerOpen12").innerHTML = "Thank You For Your Submission";
	
	var e = document.getElementById("choice1");
	var strUser = e.options[e.selectedIndex].value;
	
	var q = document.getElementById("bars");
	var barsValue = q.options[q.selectedIndex].value;
	
	var k = document.getElementById("diningcourts");
	var diningValue = k.options[k.selectedIndex].value;
	
	var j = document.getElementById("waitTime");
	var timeValue = j.options[j.selectedIndex].value;
	
	if (strUser == "diningcourts") {
		storedDiningData(diningValue,timeValue);
	}
	else if (strUser == "bars") {
		storedBarData(barsValue,timeValue);
	}
}









